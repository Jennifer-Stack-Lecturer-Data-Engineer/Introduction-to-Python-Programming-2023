#answer = lambda number, power : number ** power

#lambda expresion
#bonuses = [100, 200, 300]
#iterator = map(lambda bonus: bonus*2, bonuses)