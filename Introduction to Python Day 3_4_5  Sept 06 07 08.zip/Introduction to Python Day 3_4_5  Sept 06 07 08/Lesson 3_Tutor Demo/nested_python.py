for even in range(2,11,2):
  for odd in range(1,11,2):
    val = even + odd
    print(even, "+", odd, "=", val)