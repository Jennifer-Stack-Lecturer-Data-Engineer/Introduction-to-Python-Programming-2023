#!/usr/bin/env python3

for number in range(3):
    print(number)
