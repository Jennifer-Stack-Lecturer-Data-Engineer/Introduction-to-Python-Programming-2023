#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
bear_index = animals.index('bear')
print(bear_index)
