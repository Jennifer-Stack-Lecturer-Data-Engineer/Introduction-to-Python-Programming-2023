#!/usr/bin/env python3

days_of_the_week_tuple = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
days_of_the_week_list = list(days_of_the_week_tuple)
print('days_of_the_week_tuple is {}.'.format(type(days_of_the_week_tuple)))
print('days_of_the_week_list is {}.'.format(type(days_of_the_week_list)))

animals_list = ['man', 'bear', 'pig']
animals_tuple = tuple(animals_list)
print('animals_list is {}.'.format(type(animals_list)))
print('animals_tuple is {}.'.format(type(animals_tuple)))
