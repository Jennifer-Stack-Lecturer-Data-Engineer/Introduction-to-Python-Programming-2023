#!/usr/bin/env python3

say_hi()


def say_hi():
    print('Hi!')
