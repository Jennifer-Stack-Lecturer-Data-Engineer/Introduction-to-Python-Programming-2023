def set_maker(the_list):
  return set(the_list)