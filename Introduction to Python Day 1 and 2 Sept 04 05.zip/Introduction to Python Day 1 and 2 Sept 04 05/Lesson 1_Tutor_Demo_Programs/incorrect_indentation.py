>>> if 5 > 2:
...     print("Greater than")
...    x = 5
...   print(x * 2) 
... else:
...     print("Less than")
...    print(2)
