PI = 3.14159
radius = 7

area = PI * radius**2
circumference = 2 * PI * radius

print("Circumference of the circle:", circumference)
print("Area of the circle:", area)
