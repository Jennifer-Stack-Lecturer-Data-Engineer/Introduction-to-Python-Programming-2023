"""
This script generates a multiplication table from 1 to 10 for
any given number.
"""
number = int(input("Generate a multiplication table for: "))

print("_" * 20)
print("1:", number)
print("2:", number * 2)
print("3:", number * 3)
print("4:", number * 4)
print("5:", number * 5)
print("6:", number * 6)
print("7:", number * 7)
print("8:", number * 8)
print("9:", number * 9)
print("10:", number * 10)
print("_" * 20)
