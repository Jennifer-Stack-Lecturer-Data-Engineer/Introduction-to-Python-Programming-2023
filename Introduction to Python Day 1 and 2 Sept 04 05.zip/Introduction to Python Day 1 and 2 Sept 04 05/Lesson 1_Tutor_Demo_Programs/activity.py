"""
This module is a name tag generator.
"""

first_name = 'Jennifer'
second_name = 'Stack'

print("*---------------------------------")
print("|", "First name: ",first_name)
print("|", "Second name: ",second_name)
print("*---------------------------------")
