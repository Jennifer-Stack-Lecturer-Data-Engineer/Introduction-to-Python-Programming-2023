#!/usr/bin/env python3
a = 'apple'[0]
e = 'apple'[4]
