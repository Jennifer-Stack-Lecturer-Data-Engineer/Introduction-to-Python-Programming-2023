#!/usr/bin/env python3
first = 'I'
second = 'love'
third = 'Python'
print('{} {} {}.'.format(first, second, third))
