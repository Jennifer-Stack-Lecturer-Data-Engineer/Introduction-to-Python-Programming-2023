#!/usr/bin/env python3
fruit = input('Enter a name of a fruit: ')
print('{} is a lovely fruit.'.format(fruit))
