#!/usr/bin/env python3
sentence = "That's a great tasting apple!"
