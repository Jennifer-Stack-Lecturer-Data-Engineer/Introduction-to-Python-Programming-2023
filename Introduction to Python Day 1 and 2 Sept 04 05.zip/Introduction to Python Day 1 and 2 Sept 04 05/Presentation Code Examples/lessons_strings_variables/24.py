#!/usr/bin/env python3
print('I {} Python.'.format('love'))
print('{} {} {}'.format('I', 'love', 'Python.'))
