#!/usr/bin/env python3

quantity_string = '3'
quantity_float = float(quantity_string)
print(quantity_float)
