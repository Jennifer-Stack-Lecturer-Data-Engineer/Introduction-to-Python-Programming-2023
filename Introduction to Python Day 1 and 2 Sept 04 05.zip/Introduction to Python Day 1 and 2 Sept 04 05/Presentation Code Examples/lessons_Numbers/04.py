#!/usr/bin/env python3

quantity = 3
quantity_string = '3'
