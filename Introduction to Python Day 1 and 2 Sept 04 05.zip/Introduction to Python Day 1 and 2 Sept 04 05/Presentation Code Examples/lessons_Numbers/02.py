#!/usr/bin/env python3

sum = 1 + 2
difference = 100 - 1
product = 3 * 4
quotient = 8 / 2
power = 2 ** 4
remainder = 3 % 2

print('Sum: {}'.format(sum))
print('Difference: {}'.format(difference))
print('Product: {}'.format(product))
print('Quotient: {}'.format(quotient))
print('Power: {}'.format(power))
print('Remainder: {}'.format(remainder))
