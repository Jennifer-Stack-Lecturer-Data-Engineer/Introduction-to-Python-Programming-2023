number = input("Convert to binary: ")

# convert to integer
integer = int(number)

# convert integer to binary
binary = bin(integer)

print(binary)
