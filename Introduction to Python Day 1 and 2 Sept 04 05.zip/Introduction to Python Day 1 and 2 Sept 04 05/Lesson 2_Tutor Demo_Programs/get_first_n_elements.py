array = [55, 12, 37, 831, 57, 16, 93, 44, 22]

print("Array: ", array)
n = int(input("Number of elements to fetch from array: "))

print(array[0: n])
