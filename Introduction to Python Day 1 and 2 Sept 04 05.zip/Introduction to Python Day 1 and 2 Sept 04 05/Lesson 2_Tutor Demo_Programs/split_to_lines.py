sentence = input("Sentence: ")

sentence = sentence.replace(" ", "\n")

print(sentence, "\a")
